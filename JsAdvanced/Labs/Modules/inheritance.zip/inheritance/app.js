import Entity from "./entity";
import Dog from "./dog";
import Person from "./person";
import Student from "./student";

result.Entity = Entity;
result.Person = Person;
result.Dog = Dog;
result.Student = Student;

